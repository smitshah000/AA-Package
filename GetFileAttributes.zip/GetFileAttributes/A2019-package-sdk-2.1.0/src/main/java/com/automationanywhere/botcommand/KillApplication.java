package com.automationanywhere.botcommand;
import com.automationanywhere.botcommand.data.impl.StringValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.commandsdk.annotations.*;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import static com.automationanywhere.commandsdk.model.AttributeType.*;
import static com.automationanywhere.commandsdk.model.DataType.STRING;

//BotCommand makes a class eligible for being considered as an action.
@BotCommand

//CommandPks adds required information to be dispalable on GUI.
@CommandPkg(
        //Unique name inside a package and label to display.
        name = "KillApplication", label = "[[KillApplication.label]]",
        node_label = "[[KillApplication.node_label]]", description = "[[KillApplication.description]]", icon = "killapplication.svg",

        //Return type information. return_type ensures only the right kind of variable is provided on the UI.
        return_label = "[[KillApplication.return_label]]", return_type = STRING, return_required = true, return_description = "[[KillApplication.return_label_description]]")
public class KillApplication {

    //Identify the entry point for the action. Returns a Value<String> because the return type is String.
    @Execute

    public StringValue action(
            //Idx 1 would be displayed first, with a text box for entering the value.
            @Idx(index = "1", type = TEXT)
            //UI labels.
            @Pkg(label = "[[KillApplication.ApplicationName.label]]")
            //Ensure that a validation error is thrown when the value is null.
            @NotEmpty
                    String applicationName){

        //main action logic
        try{

            Runtime.getRuntime().exec("TASKKILL /F /IM " + applicationName);

        } catch (Exception e ){
            throw new BotCommandException("There was issue killing the following application: " + applicationName + ". Full Exception Text: " + e);
        }

        //Return StringValue.
        return new StringValue(applicationName + " killed successfully");
    }
}
