package com.automationanywhere.botcommand;
import com.automationanywhere.botcommand.data.impl.BooleanValue;
import com.automationanywhere.botcommand.exception.BotCommandException;
import com.automationanywhere.commandsdk.annotations.*;
import com.automationanywhere.commandsdk.annotations.BotCommand;
import com.automationanywhere.commandsdk.annotations.rules.NotEmpty;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import static com.automationanywhere.commandsdk.model.AttributeType.FILE;
import static com.automationanywhere.commandsdk.model.AttributeType.TEXT;
import static com.automationanywhere.commandsdk.model.DataType.BOOLEAN;

//BotCommand makes a class eligible for being considered as an action.
@BotCommand

//CommandPks adds required information to be dispalable on GUI.
@CommandPkg(

        //Unique name inside a package and label to display.
        name = "MoveFile", label = "[[MoveFile.label]]",
        node_label = "[[MoveFile.node_label]]", description = "[[MoveFile.description]]", icon = "movefile.svg",

        //Return type information. return_type ensures only the right kind of variable is provided on the UI.
        return_label = "[[MoveFile.return_label]]", return_type = BOOLEAN, return_required = true, return_description = "[[MoveFile.return_label_description]]")

public class MoveFile {

    //Identify the entry point for the action. Returns a Value<String> because the return type is String.
    @Execute
    public BooleanValue action(
            //Idx 1 would be displayed first, with a text box for entering the value.
            @Idx(index = "1", type = FILE)
            //UI labels.
            @Pkg(label = "[[MoveFile.filePath.label]]")
            //Ensure that a validation error is thrown when the value is null.
            @NotEmpty
                    String filePath,

            @Idx(index = "2", type = TEXT)
            @Pkg(label = "[[MoveFile.DestFilePath.label]]")
            @NotEmpty
                    String destPath)
        {
            //Internal validation, to disallow empty strings. No null check needed as we have NotEmpty on firstString.
            if ("".equals(filePath.trim()))
                throw new BotCommandException("Please make sure to select valid file");

            if ("".equals(filePath.trim()))
                throw new BotCommandException("Please make sure to select valid dest path");

            //Business logic

            try {

                Path temp = Files.move
                        (Paths.get(filePath),
                                Paths.get(destPath));


            } catch (Exception e) {
                throw new BotCommandException("There was a problem moving the file to " + filePath + ". Full Exception Text: " + e);
            }

            //Return StringValue
            return new BooleanValue(true);
        }
}

