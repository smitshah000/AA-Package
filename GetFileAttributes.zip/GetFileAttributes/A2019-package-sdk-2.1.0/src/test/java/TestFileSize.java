import com.automationanywhere.botcommand.GetFileDetails;
import com.automationanywhere.botcommand.KillApplication;
import com.automationanywhere.botcommand.MoveFile;
import com.automationanywhere.botcommand.data.impl.BooleanValue;
import com.automationanywhere.botcommand.data.impl.DictionaryValue;
import org.testng.annotations.Test;


public class TestFileSize {
    @Test
    public void TestGetFileDetails()
    {
        String filePath = "src/main/resources/icons/sample.svg";

        //create GetFileDetailsObject
        GetFileDetails getFileDetails = new GetFileDetails();
        DictionaryValue output = getFileDetails.action(filePath);
        System.out.println(output.get("fileSize").toString());
        System.out.println(output.get("lastModTime").toString());
        System.out.println(output.get("createDate").toString());
        System.out.println(output.get("isDirectory").toString());
        System.out.println(output.get("lastAccessTime").toString());
        //Assert.assertEquals(output.getAsDouble(),5027.0);
    }

    @Test
    public void TestMoveFile()
    {
        String orgFilePath = "C:\\Users\\smits\\Desktop\\TestMoveFile.txt";
        String destFilePath = "C:\\Users\\smits\\Desktop\\Test\\NewTestMoveFile.txt";
        MoveFile moveFile = new MoveFile();
        BooleanValue output = moveFile.action(orgFilePath,destFilePath);

    }

    @Test
    public void TestKillApplication()
    {
        String applicationName = "excel.exe";
        KillApplication killApplication = new KillApplication();
        killApplication.action(applicationName);


    }


}
